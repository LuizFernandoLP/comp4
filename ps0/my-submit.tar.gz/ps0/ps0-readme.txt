/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name:Luiz Fernando Leite Pereira

Operating system you're using (Linux, OS X, or Windows): windows

IDE or text editor you're using: notepad++

Hours to complete assignment: 6h

/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.
 **********************************************************************/

I personally believe that example five (labeled as (e)) is the one that 
will be applied the most for this class becasue by sharing our code with
our classmates (or even posting on the internet) we are actively engaging
in a conduct that is aimed at making a false representation of a student's
academic performance. This is true because by sharing our code with someone
else we end up giving our instruction the idea that the other student is having
a clear and thorough understanding of the content which in most cases is not true.
therefore, by doing that we are preventing the professor from helping other
students to succeed in the future just to get a "good" grade in a single assignment.


/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
I received help from a classmate on how to install puTTY and from the professor
to get SFML working


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I'm used to working with IDEs where I just need to press 1 button to install
everything and another 1 to compile. Because of that, I'm struggling a lot to
understand how all of those terminal commands work (like idk how the packages
are getting installed or which command I should use. of course i know the basics like
how to use gcc or g++ but if you ask me for something more complex like this
	
  g++ main.o -o sfml-app -L<sfml-install-path>/lib -lsfml-graphics -lsfml-window -lsfml-system

I probably would not be able to figure it out by myself if im not given the commands

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

my "do something else" part was to rotate my sprite by pressing R